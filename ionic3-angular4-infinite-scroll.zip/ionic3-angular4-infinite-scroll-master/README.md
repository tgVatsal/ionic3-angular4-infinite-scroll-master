# An Example of Ionic 3 Infinite Scroll or Load More

This source code is part of [An Example of Ionic 3 Infinite Scroll or Load More](https://www.djamware.com/post/59b0ac0c80aca768e4d2b139/an-example-of-ionic-3-infinite-scroll-or-load-more) tutorial.

If you think this source code is useful, it will be great if you just give it star or just buy me a cup of cofee [![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=Q5WK24UVWUGBN)

To run this example:

* Clone this repository
* Run `npm install`
* Run `ionic serve --lab`
